globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/4g_S5gIEuRjC2Y6Y_Slxp/_buildManifest.js",
    "static/4g_S5gIEuRjC2Y6Y_Slxp/_ssgManifest.js",
    "static/4g_S5gIEuRjC2Y6Y_Slxp/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3_yjp8hbo33cx.js",
    "static/chunks/1cic2vlu0tna9.js",
    "static/chunks/1qab7o0y01rp9.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-1cnoeueiesvdu.js"
  ]
};
